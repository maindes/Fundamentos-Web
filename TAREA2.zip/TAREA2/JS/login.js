/*Boton Regresar*/ 
document.getElementById("button").onclick = function() {
    window.location.href = "index.html"; 
};

/*Boton Ingresar*/ 
document.getElementById("button_back").onclick = function() {
    let name_user = document.getElementById("name_user").value;
    let password_user = document.getElementById("password_user").value;
    let real_user = "cenfo";
    let real_password = "123";

    if (name_user === "" || password_user === "") {
        Swal.fire ({
            icon: "error",
            title: "Ocurrio un error.",
            text: "Debe llenar los espacios en blanco!",
        });
        return;
    }

    if (name_user === real_user && password_user === real_password){
        Swal.fire({
            icon: 'success',
            tittle: 'Datos correctos',
            text: 'Ingresando...',
            timer: 3000,
            showConfirmButton: false,
            willClose: () => {
                window.location.href = "landing.html";
            }
        });
    } else {
        Swal.fire({
            icon: 'warning',
            title: 'Cuidado!',
            text: 'Usuario o contraseña incorrectos. Intente de nuevo',
        });
    }
}