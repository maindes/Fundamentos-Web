const panorama = new PANOLENS.ImagePanorama("imagenes/def.jpg");
const viewer = new PANOLENS.Viewer({
    container: document.getElementById("panorama-container"),
    autoHideInfospot: false
});

viewer.add(panorama);

function crearTextoToggle(contenido) {
    const elementoTexto = document.createElement('div');
    elementoTexto.className = 'infospot-texto';
    elementoTexto.innerText = contenido;
    elementoTexto.style.display = 'none';

 
    elementoTexto.style.backgroundColor = 'purple';
    elementoTexto.style.color = 'white';
    elementoTexto.style.padding = '10px';
    elementoTexto.style.borderRadius = '5px';
    elementoTexto.style.width = '150px';
    elementoTexto.style.textAlign = 'center';
    elementoTexto.style.position = 'relative';
    elementoTexto.style.marginTop = '150px';
    elementoTexto.style.zIndex = '1000';

    return elementoTexto;
}

function alternarVistaTexto(elementoTexto) {
    if (elementoTexto.style.display === 'none' || elementoTexto.style.display === '') {
        elementoTexto.style.display = 'block';
    } else {
        elementoTexto.style.display = 'none';
    }
}

const tvSpot = new PANOLENS.Infospot(2000, PANOLENS.DataImage.Info);
tvSpot.position.set(-2000, 1000, -9000);
tvSpot.addHoverText("Yt video");
tvSpot.element.innerHTML = `
    <div style="">
        <iframe margin-top="20px" margin-left"10px" height="200" width="200" src="https://www.youtube.com/embed/WlQNLSKwM5Q" allowfullscreen></iframe>
    </div>`;
panorama.add(tvSpot);


const textoPintura1 = crearTextoToggle("Esta pintura representa el estilo impresionista con colores vibrantes.");
const pintura1Spot = new PANOLENS.Infospot(1000, PANOLENS.DataImage.Info);
pintura1Spot.position.set(2500, 4000, 3800);
pintura1Spot.addHoverElement(textoPintura1, 200);
pintura1Spot.addEventListener("click", () => alternarVistaTexto(textoPintura1));
panorama.add(pintura1Spot);


const puertaSpot = new PANOLENS.Infospot(1000, PANOLENS.DataImage.Info);
puertaSpot.position.set(9000, 0, 1500);
puertaSpot.addHoverText('Audio mp3', -30);
puertaSpot.element.innerHTML = `
    <div style="">
        <audio controls><source src="audio/audio_puerta.mp3" type="audio/mp3"></audio>
    </div>`;
panorama.add(puertaSpot);


const textoPintura2 = crearTextoToggle("Esta pintura es una obra moderna inspirada en el arte abstracto.");
const pintura2Spot = new PANOLENS.Infospot(1000, PANOLENS.DataImage.Info);
pintura2Spot.position.set(9000, 2000, -4000);
pintura2Spot.addHoverElement(textoPintura2, 200);
pintura2Spot.addEventListener("click", () => alternarVistaTexto(textoPintura2));
panorama.add(pintura2Spot);


const textoCama = crearTextoToggle("Esta es una cama tamaño queen con colchón de espuma viscoelástica.");
const camaSpot = new PANOLENS.Infospot(1000, PANOLENS.DataImage.Info);
camaSpot.position.set(9000, -500, -3500);
camaSpot.addHoverElement(textoCama, 200);
camaSpot.addEventListener("click", () => alternarVistaTexto(textoCama));
panorama.add(camaSpot);


const textoCompu = crearTextoToggle("Computadora de última generación con procesador i7 y 16GB de RAM.");
const compuSpot = new PANOLENS.Infospot(1000, PANOLENS.DataImage.Info);
compuSpot.position.set(6000, 0, 5000);
compuSpot.addHoverElement(textoCompu, 200);
compuSpot.addEventListener("click", () => alternarVistaTexto(textoCompu));
panorama.add(compuSpot);


const textoReloj = crearTextoToggle("La hora actual es: " + new Date().toLocaleTimeString());
const relojSpot = new PANOLENS.Infospot(300, PANOLENS.DataImage.Info);
relojSpot.position.set(-500, 0, 2000);
relojSpot.addHoverElement(textoReloj, 200);
relojSpot.addEventListener("click", () => alternarVistaTexto(textoReloj));
panorama.add(relojSpot);


const textoEstant = crearTextoToggle("La estantería contiene una variedad de libros sobre tecnología y arte.");
const estantSpot = new PANOLENS.Infospot(300, PANOLENS.DataImage.Info);
estantSpot.position.set(-500, 600, 1000);
estantSpot.addHoverElement(textoEstant, 200);
estantSpot.addEventListener("click", () => alternarVistaTexto(textoEstant));
panorama.add(estantSpot);