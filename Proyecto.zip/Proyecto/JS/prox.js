const pelis = {
    terror: [
        { titulo: "Winnie The Pooh 2", descripcion: "Todos creen que Christopher fue el autor de la matanza, pero, mientras trata de demostrar su inocencia, Pooh, esta vez acompañado por Tigger y Búho", img: "img/terror1_prox.png" },
        { titulo: "El último Late Night", descripcion: "Halloween de 1977. Jack, el presentador de un programa de televisión, entrevista a la superviviente del suicidio en masa de una secta satánica.", img: "img/terror2_prox.jpg" },
        { titulo: "Watchers", descripcion: "Mina, una artista de 28 años, queda atrapada en un bosque irlandés junto a tres extraños, y cada noche la vigilan unas criaturas.", img: "img/terror3_prox.jpg" },
        { titulo: "El último viaje del Demeter", descripcion: "El barco mercante 'Demeter' parte de los Balcanes para entregar en Londres 50 cajas de madera sin clasificar.", img: "img/terror4_prox.jpg" },
    ],
    drama: [
        { titulo: "Joker", descripcion: "El comediante fracasado Arthur Fleck conoce al amor de su vida, Harley Quinn, mientras está en el Hospital Estatal de Arkham.", img: "img/drama1_prox.jpg" },
        { titulo: "El conde de Montecristo", descripcion: "Una adaptación moderna de la novela clásica de Alejandro Dumas sobre venganza y justicia.", img: "img/drama2_prox.jpg" },
        { titulo: "Kinds of Kindness", descripcion: "Tres historias: un hombre que trata de asumir el control de su propia vida, un policía cuya esposa parece otra persona y una mujer que busca a alguien especial.", img: "img/drama3_prox.jpg" },
        { titulo: "Apocalipsis Z", descripcion: "Una extraña enfermedad se ha extendido por el planeta, convirtiendo a las personas en criaturas violentas. Manel, que vive aislado tras la muerte de su mujer.", img: "img/drama4_prox.jpg" },
    ],
    accion: [
        { titulo: "Damsel", descripcion: "Una joven acepta casarse con un apuesto príncipe, pero descubre que todo es una trampa.", img: "img/accion1_prox.jpg" },
        { titulo: "Misión Imposible 5", descripcion: "El equipo enfrenta al Sindicato, una corporación de agentes muy preparados y dispuestos a todo para establecer un nuevo orden mundial.", img: "img/accion2_prox.jpg" },
        { titulo: "Kraven", descripcion: "El inmigrante ruso Sergei Kravinoff emprende una misión para demostrar que es el mejor cazador del mundo.", img: "img/accion3_prox.jpg" },
        { titulo: "Godzilla vs Kong", descripcion: "Godzilla y Kong se enfrentan a una amenaza colosal escondida en lo profundo del planeta, desafiando su existencia y la supervivencia de la humanidad.", img: "img/accion4_prox.jpg" },
    ],
    animadas: [
        { titulo: "IntensaMente 2", descripcion: "Ahora que es adolescente, Riley experimenta nuevos sentimientos como Ansiedad y Envidia, que se imponen a los viejos mientras ella duda sobre si abandonar a sus antiguas amigas por otras de la escuela secundaria.", img: "img/animada1.jpg" },
        { titulo: "Megamente 2", descripcion: "Cuando los excompañeros villanos de Megamente, el Sindicato de la Perdición, escapan de la prisión, el ahora héroe de Metro City debe evitar el desastre.", img: "img/animada2.jpg" },
        { titulo: "Kung Fu Panda 4", descripcion: "Po está entrenando a un nuevo guerrero que ocupe su lugar para que él pueda convertirse en líder espiritual del Valle de la Paz.", img: "img/animada3.jpg" },
        { titulo: "Transformers One", descripcion: "La historia nunca antes contada del origen de Optimus Prime y Megatron, quienes en su juventud fueron hermanos de armas.", img: "img/animada4.jpg" },
    ]
};

function busqPelis() {
    const genero = document.getElementById("busq").value.toLowerCase();
    const container = document.getElementById("pelis-container");
    container.innerHTML = "";
    if (pelis[genero]) {
        pelis[genero].forEach(pelicula => {
            const tarjetaPelicula = document.createElement("div");
            tarjetaPelicula.className = "cardPelis";
            tarjetaPelicula.innerHTML = `
                <img src="${pelicula.img}" alt="${pelicula.titulo}">
                <div class="pelis-info">
                    <h2>${pelicula.titulo}</h2>
                    <p>${pelicula.descripcion}</p>
                    <h3>Disponibilidad</h3>
                    <div class="combo-container">
                        <select id="ubicacion-${pelicula.titulo}">
                            <option value="San Jose">San Jose</option>
                            <option value="Heredia">Heredia</option>
                            <option value="Cartago">Cartago</option>
                            <option value="Alajuela">Alajuela</option>
                        </select>
                        <select id="dia-${pelicula.titulo}">
                            <option value="Lunes">Lunes</option>
                            <option value="Martes">Martes</option>
                            <option value="Miércoles">Miércoles</option>
                            <option value="Jueves">Jueves</option>
                            <option value="Viernes">Viernes</option>
                            <option value="Sábado">Sábado</option>
                            <option value="Domingo">Domingo</option>
                        </select>
                        <button onclick="verificarDisponibilidad('${pelicula.titulo}', '${pelicula.img}')">Consultar</button>
                    </div>
                </div>
            `;
            container.appendChild(tarjetaPelicula);
        });
    } else {
        Swal.fire({
            title: "Error",
            text: "Debe escribir el género de cine",
            icon: "error"
        });
    }
}

function verificarDisponibilidad(titulo, img) {
    const ubicacion = document.getElementById(`ubicacion-${titulo}`).value;
    const dia = document.getElementById(`dia-${titulo}`).value;
    
    const disponible = (dia === "Viernes" || dia === "Sábado" || dia === "Domingo") && (ubicacion === "San Jose" || ubicacion === "Heredia" || ubicacion === "Alajuela");
    Swal.fire({
        title: titulo,
        text: `${ubicacion}, ${dia} - ${disponible ? "Disponible" : "No Disponible"}`,
        imageUrl: img,
        imageWidth: 200,
        imageAlt: titulo,
        confirmButtonText: "Ok",
        background: "rgb(24, 24, 32)",
        color: "white"
    });
}