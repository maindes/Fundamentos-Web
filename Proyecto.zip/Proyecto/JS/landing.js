document.getElementById("button_sitio").onclick = function() {
    window.location.href = "inicio.html"; 
};

document.getElementById("button_app").onclick = function() {
    window.location.href = "preventa.html"; 
};