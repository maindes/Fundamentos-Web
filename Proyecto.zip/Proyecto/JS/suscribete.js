(function cargarEmailJS() {
    const script = document.createElement("script");
    script.src = "https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js";
    script.onload = () => {
        emailjs.init("B_1qj3zW81Xk3SR1J"); 
        console.log("EmailJS cargado e inicializado");
    };
    script.onerror = () => console.error("Error al cargar EmailJS");
    document.head.appendChild(script);
})();


document.getElementById("enviarSuscripcion").addEventListener("click", function (event) {
    event.preventDefault(); 
    const email = document.getElementById("emailSuscripcion").value.trim();
    const email_espacio = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!email) {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Debe llenar el espacio del email',
            timer: 3000,
            timerProgressBar: true,
        });
        return;
    }

    if (!email_espacio.test(email)) {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Por favor ingrese un correo válido',
            timer: 3000,
            timerProgressBar: true,
        });
        return;
    }

    
    if (typeof emailjs !== "undefined" && emailjs.send) {
        emailjs.send("service_3yw9gtv", "template_p3jzhj1", { email: email })
            .then(() => {
                Swal.fire({
                    icon: 'success',
                    title: '¡Enviado!',
                    text: 'Tu correo ha sido registrado exitosamente.',
                });
                document.getElementById("emailSuscripcion").value = ""; 
            })
            .catch((error) => {
                Swal.fire({
                    icon: 'error',
                    title: 'Error al enviar',
                    text: `Hubo un problema al enviar el correo: ${error.text}`,
                });
            });
    } else {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'EmailJS aún no está cargado. Por favor, intente de nuevo.',
        });
    }
});

$(document).ready(function () {
    $(".owl-carousel").owlCarousel({
        loop: true,
        margin: 20,
        nav: true,
        dots: false,
        autoplay: true,
        autoplayTimeout: 5000,
        autoplayHoverPause: true,
        responsive: {
            0: {
                items: 1
            },
            600: {
                items: 2
            },
            1000: {
                items: 3
            }
        }
    });
});

