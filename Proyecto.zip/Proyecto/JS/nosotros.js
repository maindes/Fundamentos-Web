document.getElementById("ubicacion").addEventListener("change", function() {
    const ubicacion = document.getElementById("ubicacion").value;
    let url;

    switch (ubicacion) {
        case "san-jose":
            url = "https://tumallsanpedro.com/";
            break;
        case "heredia":
            url = "https://oxigeno.com/";
            break;
        case "alajuela":
            url = "https://citymall.net/?gad_source=1&gclid=Cj0KCQiAire5BhCNARIsAM53K1g5MN_vfBOY5hF0Ujd6W7AFtFtolpnK1udfhV2EIIp0KoyU06vXyJwaAnGtEALw_wcB";
            break;
        case "cartago":
            url = "https://www.terramall.co.cr/";
            break;
        default:
            url = "";
    }

    if (url) {
        window.open(url, "_blank");
    }
});

//Encuesta
document.getElementById("borrar").addEventListener("click", function() {
    document.querySelectorAll('input[type="checkbox"]').forEach(el => el.checked = false);
    document.querySelectorAll('input[type="radio"]').forEach(el => el.checked = false);
    document.getElementById("comentarios").value = "";
    document.getElementById("email").value = "";
});

document.getElementById("enviar").addEventListener("click", function () {
    const checkboxes = document.querySelectorAll('input[type="checkbox"]:checked').length;
    const radiosLimpieza = document.querySelectorAll('input[name="limpieza"]:checked').length;
    const radiosRecomendacion = document.querySelectorAll('input[name="recomendacion"]:checked').length;
    const comentarios = document.getElementById("comentarios").value.trim();
    const email = document.getElementById("email").value.trim();
    const email_espacio = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    if (!checkboxes || !radiosLimpieza || !radiosRecomendacion || !comentarios) {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Debe llenar todos los espacios antes de enviar la encuesta.',
        });
    } else if (!email_espacio.test(email)) {
        Swal.fire({
            icon: 'warning',
            title: 'Correo Inválido',
            text: 'Por favor, ingrese un correo electrónico válido.',
        });
    } else {
        emailjs
            .sendForm('service_3yw9gtv', 'template_lunxddm', '#formEncuesta', 'B_1qj3zW81Xk3SR1J')
            .then(() => {
                Swal.fire({
                    icon: 'success',
                    title: '¡Excelente!',
                    text: 'Tus respuestas fueron enviadas correctamente',
                });

                document.querySelectorAll('input[type="checkbox"]').forEach(el => (el.checked = false));
                document.querySelectorAll('input[type="radio"]').forEach(el => (el.checked = false));
                document.getElementById("comentarios").value = "";
                document.getElementById("email").value = "";
            })
            .catch((error) => {
                Swal.fire({
                    icon: 'error',
                    title: 'Error al enviar',
                    text: `Hubo un problema al enviar el correo: ${error.text}`,
                });
            });
    }
});

// Lightbox 
const lightbox = document.getElementById('lightbox');
const boton_abrir = document.querySelector('.abrir_video');
const boton_cerrar = document.getElementById('cerrar_video');
const iframe = lightbox.querySelector('iframe');


boton_abrir.addEventListener('click', () => {
  lightbox.style.display = 'flex';
});

boton_cerrar.addEventListener('click', () => {
  lightbox.style.display = 'none';
  iframe.src = iframe.src; 
});

lightbox.addEventListener('click', (e) => {
  if (e.target === lightbox) {
    lightbox.style.display = 'none';
    iframe.src = iframe.src; 
  }
});


// Carousel 
const carousel_fotos = document.querySelector('.carousel_fotos');
const fotos = document.querySelectorAll('.carousel_fotos img');
const boton_izq = document.querySelector('.boton_izq');
const boton_der = document.querySelector('.boton_der');

let index = 0;

function foto_dere() {
    index = (index + 1) % fotos.length;
    act_carousel();
}

function foto_izq() {
    index = (index - 1 + fotos.length) % fotos.length;
    act_carousel();
}

function act_carousel() {
    const offset = -index * fotos[0].clientWidth;
    carousel_fotos.style.transform = `translateX(${offset}px)`;
}

boton_der.addEventListener('click', foto_dere);
boton_izq.addEventListener('click', foto_izq);


// Pestañas
const botonTab = document.querySelectorAll('.boton_tab');
const contenidoTab = document.querySelectorAll('.contenido');

botonTab.forEach(boton => {
    boton.addEventListener('click', () => {
        botonTab.forEach(btn => btn.classList.remove('active'));
        contenidoTab.forEach(contenido => contenido.classList.remove('active'));

        
        boton.classList.add('active');
        const tab = document.querySelector(`#${boton.dataset.tab}`);
        tab.classList.add('active');
    });
});

window.addEventListener('DOMcontenidoLoaded', () => {
    contenidoTab.forEach(contenido => contenido.classList.remove('active'));
    botonTab.forEach(btn => btn.classList.remove('active'));
});

//carousel
$(document).ready(function () {
    $('.patrocinadores-carousel').owlCarousel({
        loop: true,
        margin: 10,
        nav: false, 
        responsive: {
            0: {
                items: 2
            },
            600: {
                items: 4
            },
            1000: {
                items: 6
            }
        }
    });

    $('.owl-prev').click(function () {
        $('.patrocinadores-carousel').trigger('prev.owl.carousel');
    });

    $('.owl-desp').click(function () {
        $('.patrocinadores-carousel').trigger('next.owl.carousel');
    });
});
