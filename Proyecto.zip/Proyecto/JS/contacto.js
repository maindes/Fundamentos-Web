(function cargarEmailJS() {
    const script = document.createElement("script");
    script.src = "https://cdn.jsdelivr.net/npm/emailjs-com@3/dist/email.min.js";
    script.onload = () => {
        emailjs.init("QqFkrd-dqRysD2B3y"); 
        console.log("EmailJS cargado e inicializado");
    };
    script.onerror = () => console.error("Error al cargar EmailJS");
    document.head.appendChild(script);
})();

document.getElementById("enviarFormulario").addEventListener("click", function (event) {
    event.preventDefault(); 

   
    const nombre = document.getElementById("nombre").value.trim();
    const apellido = document.getElementById("apellido").value.trim();
    const email = document.getElementById("email").value.trim();
    const telefono = document.getElementById("telefono").value.trim();
    const mensaje = document.getElementById("mensaje").value.trim();
    const email_espacio = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;

    
    if (!nombre || !apellido || !email || !telefono || !mensaje) {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Por favor, completa todos los campos.',
            timer: 3000,
            timerProgressBar: true,
        });
        return;
    }

    if (!email_espacio.test(email)) {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Por favor, ingresa un correo válido.',
            timer: 3000,
            timerProgressBar: true,
        });
        return;
    }


    const parametro = {
        nombre: nombre,
        apellido: apellido,
        email: email,
        telefono: telefono,
        mensaje: mensaje,
    };

    emailjs.send("service_3w1ssyu", "template_yiginwu", parametro)
        .then(() => {
            Swal.fire({
                icon: 'success',
                title: '¡Éxito!',
                text: 'Tu mensaje ha sido enviado exitosamente.',
            });
            document.getElementById("formContacto").reset(); 
        })
        .catch((error) => {
            Swal.fire({
                icon: 'error',
                title: 'Error al enviar',
                text: `Hubo un problema al enviar tu mensaje: ${error.text}`,
            });
        });
});

