document.addEventListener('DOMContentLoaded', function () {
    const generoEleccion = document.getElementById('seleccion_genero');
    const generoInfo = document.getElementById('genero-info');

    const generoImagenes = {
        terror: [
            { src: 'img/terror1.jpg', titulo: 'Terrifier3' },
            { src: 'img/terror2.jpg', titulo: 'Saw X' },
            { src: 'img/terror3.jpg', titulo: 'Alien' },
            { src: 'img/terror4.jpg', titulo: 'The First Omen' }
        ],
        accion: [
            { src: 'img/accion1.jpg', titulo: 'Furiosa' },
            { src: 'img/accion2.jpg', titulo: 'Misón Hostil' },
            { src: 'img/accion3.jpg', titulo: 'El protector' },
            { src: 'img/accion4.jpg', titulo: 'Bade Miyan Chote Miyan' }
        ],
        drama: [
            { src: 'img/drama1.jpg', titulo: 'El Salto' },
            { src: 'img/drama2.jpg', titulo: 'Descansar en Paz' },
            { src: 'img/drama3.jpg', titulo: 'Dañado' },
            { src: 'img/drama4.jpg', titulo: 'Especialista' }
        ],
        superheroes: [
            { src: 'img/heroes1.jpg', titulo: 'Deadpool & Wolverine' },
            { src: 'img/heroes2.jpg', titulo: 'SpiderMan: Sin Regreso a casa' },
            { src: 'img/heroes3.jpg', titulo: 'Venom' },
            { src: 'img/heroes4.jpg', titulo: 'Hanu Man' }
        ]
    };

    generoEleccion.addEventListener('change', function () {
        const generoElegido = generoEleccion.value;
        
        generoInfo.innerHTML = '';

        if (generoElegido !== 'none') {
            
            const generoTitulo = document.createElement('h3');
            generoTitulo.textContent = generoElegido.charAt(0).toUpperCase() + generoElegido.slice(1);
            generoTitulo.classList.add('genero-titulo-seleccionado');
            generoInfo.appendChild(generoTitulo);

            
            const imagenesContainer = document.createElement('div');
            imagenesContainer.classList.add('genero-imagenes');
            
            
            generoImagenes[generoElegido].forEach(pelicula => {
                const imgContainer = document.createElement('div');
                imgContainer.classList.add('pelicula-container');

                const img = document.createElement('img');
                img.src = pelicula.src;
                img.alt = pelicula.titulo;
                
                const titulo = document.createElement('p');
                titulo.classList.add('titulo-pelicula');
                titulo.textContent = pelicula.titulo;

                const subtitulo = document.createElement('p');
                subtitulo.classList.add('subtitulo-pelicula');
                subtitulo.textContent = 'Solo en cines';

                imgContainer.appendChild(img);
                imgContainer.appendChild(titulo);
                imgContainer.appendChild(subtitulo);
                imagenesContainer.appendChild(imgContainer);
            });

            generoInfo.appendChild(imagenesContainer);
        }
    });
});
