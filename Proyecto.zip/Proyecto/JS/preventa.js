const imgs = document.querySelectorAll(".proxFotos_container img");
const container_pri = document.querySelector(".proxFotos_container");

imgs.forEach((imagen) => {
  imagen.addEventListener("click", () => {
    imgs.forEach((img) => (img.style.display = "none"));

    const imgSelect = document.createElement("img");
    imgSelect.src = imagen.src;
    imgSelect.style.width = "300px";
    imgSelect.style.height = "350px";
    imgSelect.style.borderRadius = "10px";
    imgSelect.style.marginLeft = "auto";
    imgSelect.style.marginRight = "0";
    imgSelect.style.display = "block";

    const nombrePeli = imagen.alt; 

    const form_cont = document.createElement("div");
    form_cont.style.marginTop = "20px";

    const fecha_select = document.createElement("label");
    fecha_select.textContent = "Selecciona la fecha:";
    fecha_select.style.display = "block";
    fecha_select.style.marginBottom = "5px";
    fecha_select.style.color = "white";
    const fecha = document.createElement("select");
    fecha.style.display = "block";
    fecha.style.marginBottom = "20px";
    fecha.style.width = "90%";
    fecha.style.padding = "10px";
    fecha.innerHTML = `
      <option value="">Elige una fecha</option>
      <option value="2024-12-04">4 Diciembre 2024</option>
      <option value="2024-12-05">5 Diciembre 2024</option>
      <option value="2024-12-06">6 Diciembre 2024</option>
      <option value="2024-12-07">7 Diciembre 2024</option>
      <option value="2024-12-08">8 Diciembre 2024</option>
      <option value="2024-12-09">9 Diciembre 2024</option>
      <option value="2024-12-10">10 Diciembre 2024</option>
    `;

    const sede = document.createElement("label");
    sede.textContent = "Selecciona la sede:";
    sede.style.display = "block";
    sede.style.marginBottom = "5px";
    sede.style.color = "white";
    const selectorSede = document.createElement("select");
    selectorSede.style.display = "block";
    selectorSede.style.marginBottom = "20px";
    selectorSede.style.width = "90%";
    selectorSede.style.padding = "10px";
    selectorSede.innerHTML = `
      <option value="">Elige una sede</option>
      <option value="san-jose">San José</option>
      <option value="alajuela">Alajuela</option>
      <option value="heredia">Heredia</option>
      <option value="cartago">Cartago</option>
    `;

    const sala = document.createElement("label");
    sala.textContent = "Selecciona una sala:";
    sala.style.display = "block";
    sala.style.marginBottom = "5px";
    sala.style.color = "white";
    const selectorSala = document.createElement("select");
    selectorSala.style.display = "block";
    selectorSala.style.marginBottom = "20px";
    selectorSala.style.width = "90%";
    selectorSala.style.padding = "10px";
    selectorSala.innerHTML = `
      <option value="">Elige una sala</option>
      <option value="sala1">Sala 1</option>
      <option value="sala2">Sala 2</option>
      <option value="sala3">Sala 3</option>
      <option value="sala4">Sala 4</option>
      <option value="sala5">Sala 5</option>
      <option value="sala6">Sala 6</option>
      <option value="sala7">Sala 7</option>
    `;

    const hora = document.createElement("label");
    hora.textContent = "Selecciona la hora:";
    hora.style.display = "block";
    hora.style.marginBottom = "5px";
    hora.style.color = "white";
    const hora_cont = document.createElement("div");
    hora_cont.style.display = "flex";
    hora_cont.style.gap = "10px";
    hora_cont.style.marginBottom = "20px";
    const horasDisponibles = ["10:00 AM", "12:00 PM", "2:00 PM", "4:00 PM", "6:00 PM"];
    let hora_select = null;
    horasDisponibles.forEach((hora) => {
      const boton = document.createElement("button");
      boton.textContent = hora;
      boton.style.padding = "10px 20px";
      boton.style.border = "none";
      boton.style.borderRadius = "5px";
      boton.style.backgroundColor = "#00a0d9";
      boton.style.color = "white";
      boton.style.cursor = "pointer";

      boton.addEventListener("click", () => {
        hora_cont.querySelectorAll("button").forEach((btn) => {
          btn.style.backgroundColor = "#00a0d9";
        });
        boton.style.backgroundColor = "#543c83";
        hora_select = hora;
      });

      hora_cont.appendChild(boton);
    });

    const entradas = document.createElement("label");
    entradas.textContent = "Cantidad de entradas:";
    entradas.style.display = "block";
    entradas.style.marginBottom = "5px";
    entradas.style.color = "white";

    const entradas_cont = document.createElement("div");
    entradas_cont.style.display = "flex";
    entradas_cont.style.gap = "20px";

    const tiposEntradas = ["Adultos", "Niños", "Adultos Mayores"];
    const precios = { Adultos: 5000, Niños: 3000, "Adultos Mayores": 3500 };
    const entradasInputs = {};
    tiposEntradas.forEach((tipo) => {
      const entradaDiv = document.createElement("div");
      const etiquetaEntrada = document.createElement("label");
      etiquetaEntrada.textContent = tipo;
      etiquetaEntrada.style.display = "block";
      etiquetaEntrada.style.color = "white";
      const entradaInput = document.createElement("input");
      entradaInput.type = "number";
      entradaInput.min = "0";
      entradaInput.style.width = "100px";
      entradasInputs[tipo] = entradaInput;
      entradaDiv.appendChild(etiquetaEntrada);
      entradaDiv.appendChild(entradaInput);
      entradas_cont.appendChild(entradaDiv);
    });

    const botones = document.createElement("div");
    botones.style.display = "flex";
    botones.style.gap = "20px";
    botones.style.marginTop = "20px";

    const btnVolver = document.createElement("button");
    btnVolver.textContent = "⬅ Volver";
    btnVolver.style.padding = "10px 20px";
    btnVolver.style.backgroundColor = "#00a0d9";
    btnVolver.style.color = "white";
    btnVolver.style.border = "none";
    btnVolver.style.borderRadius = "5px";
    btnVolver.style.cursor = "pointer";

    btnVolver.addEventListener("click", () => {
      container_pri.innerHTML = "";
      imgs.forEach((img) => {
        img.style.display = "block";
        container_pri.appendChild(img);
      });
    });

    const btnBorrar = document.createElement("button");
    btnBorrar.textContent = "Borrar";
    btnBorrar.style.padding = "10px 20px";
    btnBorrar.style.backgroundColor = "#ff4d4d";
    btnBorrar.style.color = "white";
    btnBorrar.style.border = "none";
    btnBorrar.style.borderRadius = "5px";
    btnBorrar.style.cursor = "pointer";

    btnBorrar.addEventListener("click", () => {
      fecha.value = "";
      selectorSede.value = "";
      selectorSala.value = "";
      hora_select = null;
      hora_cont.querySelectorAll("button").forEach((btn) => {
        btn.style.backgroundColor = "#00a0d9";
      });
      Object.values(entradasInputs).forEach((input) => {
        input.value = "";
      });
    });

    const btnEnviar = document.createElement("button");
    btnEnviar.textContent = "Enviar";
    btnEnviar.style.padding = "10px 20px";
    btnEnviar.style.backgroundColor = "#00a0d9";
    btnEnviar.style.color = "white";
    btnEnviar.style.border = "none";
    btnEnviar.style.borderRadius = "5px";
    btnEnviar.style.cursor = "pointer";

    btnEnviar.addEventListener("click", () => {
      const campos_llenos =
        fecha.value &&
        selectorSede.value &&
        selectorSala.value &&
        hora_select &&
        Object.values(entradasInputs).some((input) => input.value);

      if (!campos_llenos) {
        Swal.fire({
          icon: "error",
          title: "Error",
          text: "Debe llenar todos los espacios.",
        });
      } else {
        const total = Object.entries(entradasInputs).reduce((acc, [key, input]) => {
          return acc + precios[key] * Number(input.value || 0);
        }, 0);

        Swal.fire({
          icon: "success",
          html: `
            <div>
              <img src="${imgSelect.src}" style="width: 100px; border-radius: 10px;"><br>
              <strong>${nombrePeli}</strong><br>
              <strong>Fecha: </strong> ${fecha.value}<br>
              <strong>Sede: </strong> ${selectorSede.value}<br>
              <strong>Sala: </strong> ${selectorSala.value}<br>
              <strong>Hora: </strong> ${hora_select}<br>
              <strong>Total: </strong> ₡${total}<br>
              <p> ¿Desea concretar el pago? </p>
            </div>
          `,
          showCancelButton: true,
          confirmButtonText: "Aceptar",
          cancelButtonText: "Cancelar",
          customClass: {
            cancelButton: "boton_cancelar",
            confirmButton: "boton_aceptar",
          },
        }).then((result) => {
          if (result.isConfirmed) {
            window.location.href = "pago.html";
          }
        });
      }
    });

    botones.appendChild(btnVolver);
    botones.appendChild(btnBorrar);
    botones.appendChild(btnEnviar);

    form_cont.appendChild(fecha_select);
    form_cont.appendChild(fecha);
    form_cont.appendChild(sede);
    form_cont.appendChild(selectorSede);
    form_cont.appendChild(sala);
    form_cont.appendChild(selectorSala);
    form_cont.appendChild(hora);
    form_cont.appendChild(hora_cont);
    form_cont.appendChild(entradas);
    form_cont.appendChild(entradas_cont);
    form_cont.appendChild(botones);

    container_pri.innerHTML = "";
    container_pri.appendChild(imgSelect);
    container_pri.appendChild(form_cont);
  });
});