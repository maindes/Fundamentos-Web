//CAMBIO IDOMA
const translations = {
    es: {
        encabezado: "SPACEF🚀LM",
        slogan: "¡Las mejores peliculas en tu sala preferida!",
        promoTitulo: "Descuentos y promociones de Semana Cine",
        listaPromos: ["20% en Combos", "40% en Sala VIP", "Sorteo de entradas a la pelicula que desees"],
        cartelera: "Cartelera",
        proximamente: "Proximamente",
        contadorTitulo: "Estadísticas de nuestro cine",
        contadorTextos: ["Entradas Vendidas", "Asistentes Totales", "Películas Proyectadas", "Alimentos Vendidos"], 
        footer: {
            derechos: "Derechos reservados",
            space: "SpaceFilm.Corp 2024@"
        },
        navbar: ["Inicio", "Nosotros", "Cartelera", "Preventa", "Proximamente", "Suscribete", "Contacto"]
    },
    en: {
        encabezado: "SPACEF🚀LM",
        slogan: "The best movies in your favorite theater!",
        promoTitulo: "Discounts and promotions for Cinema Week",
        listaPromos: ["20% off Combos", "40% off VIP Room", "Ticket raffle for the movie of your choice"],
        cartelera: "Billboard",
        proximamente: "Coming Soon",
        contadorTitulo: "Our Cinema Statistics",
        contadorTextos: ["Tickets Sold", "Total Attendees", "Movies Shown", "Food Items Sold"],
        footer: {
            derechos: "All rights reserved",
            space: "SpaceFilm.Corp 2024@"
        },
        navbar: ["HomePage", "About Us", "Billboard", "Pre-Sale", "Coming Soon", "Subscribe", "Contact"]
    }
};


function cambiarIdioma(lang) {
    document.querySelector('.encabezado').textContent = translations[lang].encabezado;
    document.querySelector('.slogan').textContent = translations[lang].slogan;
    document.querySelector('.promoTitulo').textContent = translations[lang].promoTitulo;

    
    const promoListItems = document.querySelectorAll('.listaPromos li');
    translations[lang].listaPromos.forEach((text, index) => {
        promoListItems[index].textContent = text;
    });

    document.querySelector('.text_Cartelera').textContent = translations[lang].cartelera;
    document.querySelector('.text_prox').textContent = translations[lang].proximamente;

    document.querySelector('.derechos').textContent = translations[lang].footer.derechos;
    document.querySelector('.space').textContent = translations[lang].footer.space;

    const navbarLinks = document.querySelectorAll('.navbar nav a');
    translations[lang].navbar.forEach((text, index) => {
        navbarLinks[index].textContent = text;
    });

    document.querySelector('.seccion_contador .titulo').textContent = translations[lang].contadorTitulo;
    const contadorTextos = document.querySelectorAll('.seccion_contador p');
    translations[lang].contadorTextos.forEach((text, index) => {
        contadorTextos[index].textContent = text;
    });
}

//contador
$(document).ready(function () {
    $('.number').each(function () {
      const $this = $(this);
      const target = $this.data('target'); 
  
      $this.waypoint(
        function () {
          
          $this.animateNumber(
            {
              number: target, 
            },
            5000 
          );
          this.destroy(); 
        },
        {
          offset: '70%', 
        }
      );
    });
});

//Obj 3D
const escena = new THREE.Scene(); 
const camara = new THREE.PerspectiveCamera(75, 1, 0.1, 1000); 
const renderizado = new THREE.WebGLRenderer({ antialias: true, alpha: true }); 
renderizado.setSize(300, 600); 
document.getElementById("obj_container").appendChild(renderizado.domElement); 

const luzD = new THREE.DirectionalLight(0xffffff, 1);
luzD.position.set(5, 10, 7.5); 
escena.add(luzD); 

const luzA = new THREE.AmbientLight(0xffffff, 0.5); 
escena.add(luzA); 

camara.position.set(0, 2, 10); 

const controles = new THREE.OrbitControls(camara, renderizado.domElement); 
controles.enableDamping = true;
controles.dampingFactor = 0.25;
controles.screenSpacePanning = false; 

const carga = new THREE.GLTFLoader();
carga.load(
  'OBJ 3D/popcorn_3D.glb', 
  (gltf) => {
    const modelo = gltf.scene; 
    modelo.position.set(-7.5, 3, 0); 
    escena.add(modelo); 
  },
  (xhr) => {
    console.log((xhr.loaded / xhr.total) * 100 + '% cargado'); 
  },
  (error) => {
    console.error('Error al cargar el modelo:', error); 
  }
);

function animar() {
  requestAnimationFrame(animar); 
  controles.update(); 
  renderizado.render(escena, camara); 
}
animar();