document.getElementById("button").onclick = function() {
    window.location.href = "login.html"; 
};