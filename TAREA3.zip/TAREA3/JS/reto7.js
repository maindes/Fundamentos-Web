$("#aros").click(function() {
    Swal.fire({
        title: 'Aros',
        text: 'Los aros del carro están diseñados para darle estabilidad y estilo. Mejoran la eficiencia en el manejo y el rendimiento general.',
        icon: 'info',
        confirmButtonText: 'Aceptar'
    });
});

$("#neum").click(function() {
    Swal.fire({
        title: 'Neumáticos',
        text: 'Los neumáticos juegan un papel vital en la seguridad y eficiencia de conducción. Elige neumáticos de calidad para un mejor rendimiento.',
        icon: 'info',
        confirmButtonText: 'Aceptar'
    });
});


$("#luces").click(function() {
    Swal.fire({
        title: 'Luces',
        text: 'Las luces del coche proporcionan visibilidad en la carretera, especialmente en condiciones de poca luz o mal tiempo.',
        icon: 'info',
        confirmButtonText: 'Aceptar'
    });
});


$("#interior").click(function() {
    Swal.fire({
        title: 'Interior',
        text: 'El interior del coche está equipado con tecnología de vanguardia para una experiencia de conducción cómoda y segura.',
        icon: 'info',
        confirmButtonText: 'Aceptar'
    });
});


$("#motor").click(function() {
    Swal.fire({
        title: 'Motor',
        text: 'El motor es el corazón del carro, proporcionando la potencia necesaria para que el vehículo funcione de manera eficiente.',
        icon: 'info',
        confirmButtonText: 'Aceptar'
    });
});