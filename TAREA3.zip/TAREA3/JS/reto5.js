function actImgPeli() {
    const pelicula = document.getElementById('peli').value;
    const imagenPelicula = document.getElementById('imagenPeli');

    let imagenDir = '';
    switch (pelicula) {
        case 'terror':
            imagenDir = 'imagenes/foto_peli_terror.png';
            break;
        case 'drama':
            imagenDir = 'imagenes/foto_peli_drama.png'; 
            break;
        case 'accion':
            imagenDir = 'imagenes/foto_peli_accion.png'; 
            break;
        case 'superheroes':
            imagenDir = 'imagenes/foto_peli_SH.png'; 
            break;
        default:
            imagenDir = ''; 
    }

    if (imagenDir) {
        imagenPelicula.src = imagenDir;
        imagenPelicula.style.display = 'block'; 
    } else {
        imagenPelicula.style.display = 'none'; 
    }
}

function calcularPrecio() {
    const pelicula = document.getElementById("peli").value;
    const tipoEntrada = document.getElementById("tipoEntrada").value;
    let precioBase;
    let precioEntrada;
    let peliculaImg;

    if (!pelicula || !tipoEntrada) {
        Swal.fire({
            icon: 'error',
            title: 'Error',
            text: 'Debe seleccionar una película y tipo de entrada.'
        });
        return;
    }

    switch (pelicula) {
        case "terror":
            precioBase = 2000;
            peliculaImg = 'imagenes/foto_peli_terror.png';
            break;
        case "drama":
            precioBase = 4000;
            peliculaImg = 'imagenes/foto_peli_drama.png';
            break;
        case "accion":
            precioBase = 6000;
            peliculaImg = 'imagenes/foto_peli_accion.png';
            break;
        case "superheroes":
            precioBase = 8000;
            peliculaImg = 'imagenes/foto_peli_SH.png';
            break;
    }

    if (tipoEntrada === "normal") {
        precioEntrada = 5000;
    } else if (tipoEntrada === "vip") {
        precioEntrada = 15000;
    }

    const total = precioBase + precioEntrada;

    Swal.fire({
        title: `Película: ${pelicula.charAt(0).toUpperCase() + pelicula.slice(1)}`,
        text: `Entrada: ${tipoEntrada.toUpperCase()} - Precio total: ₡${total}`,
        imageUrl: peliculaImg,
        imageWidth: 100,
        imageHeight: 100,
        imageAlt: 'Imagen de la película',
        confirmButtonText: 'OK'
    });
}