function mostrarImagen() {
    const selectElement = document.getElementById("equipo");
    const imagenEquipo = document.getElementById("imagenEquipo");
    const descripcion = document.getElementById("descripcion");

    const equipoSeleccionado = selectElement.value;

    imagenEquipo.src = "";
    imagenEquipo.alt = "";
    imagenEquipo.style.display = "none";
    descripcion.textContent = "";

    if (equipoSeleccionado === "real-madrid") {
        imagenEquipo.src = "imagenes/logo_madrid.png"; 
        imagenEquipo.alt = "Real Madrid";
        descripcion.textContent = "El Real Madrid es el equipo mas ganador en la historia de la champions.";
    } else if (equipoSeleccionado === "barcelona") {
        imagenEquipo.src = "imagenes/logo_barca.png"; 
        imagenEquipo.alt = "FC Barcelona";
        descripcion.textContent = "El Barcelona es el equipo que actualmente va de primero en La Liga";
    } else if (equipoSeleccionado === "juventus") {
        imagenEquipo.src = "imagenes/logo_juve.png"; 
        imagenEquipo.alt = "Juventus";
        descripcion.textContent = "La Juventos, equipo Italiano que volvio a la champios este año";
    } else if  (equipoSeleccionado === "manchester-united") {
        imagenEquipo.src = "imagenes/logo_united.png"; 
        imagenEquipo.alt = "Manchester United";
        descripcion.textContent = "Manchester United es un equipo ingles que actualmente disputa la europa League.";
    } else if (equipoSeleccionado === "bayern-munich") {
        imagenEquipo.src = "imagenes/logo_bayer.png"; 
        imagenEquipo.alt = "Bayern Munich";
        descripcion.textContent = "El Bayern Munich es el equipo mas ganador de la liga alemana. La Bundesliga.";
    }

    if (imagenEquipo.src) {
        imagenEquipo.style.display = "block";
    }
}

