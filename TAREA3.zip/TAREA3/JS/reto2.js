function dolaresAColones() {
    const montoDolares = document.getElementById('montoDolares').value;
    const tipoCambioDolares = document.getElementById('tipoCambioDolares').value;

    if (montoDolares === '' || tipoCambioDolares === '') {
        Swal.fire({
            title: "Error",
            text: "Los espacios deben estar completos",
            icon: "error"
          });
        return;
    }

    const resultado = montoDolares * tipoCambioDolares;
    document.getElementById('resultadoDolares').value = resultado.toFixed(2);
}

function colonesADolares() {
    const montoColones = document.getElementById('montoColones').value;
    const tipoCambioColones = document.getElementById('tipoCambioColones').value;

    if (montoColones === '' || tipoCambioColones === '') {
        Swal.fire({
            title: "Error",
            text: "Los espacios deben estar completos",
            icon: "error"
          });
        return;
    }

    const resultado = montoColones / tipoCambioColones;
    document.getElementById('resultadoColones').value = resultado.toFixed(2);
}

function limpiarDolares() {
    document.getElementById('montoDolares').value = '';
    document.getElementById('tipoCambioDolares').value = '';
    document.getElementById('resultadoDolares').value = '';
}

function limpiarColones() {
    document.getElementById('montoColones').value = '';
    document.getElementById('tipoCambioColones').value = '';
    document.getElementById('resultadoColones').value = '';
}