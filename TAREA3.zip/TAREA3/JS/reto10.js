const empleados = {
    "310111213": {
        nombre: "Eduardo",
        apellidos: "Jimenez Muñoz",
        lugar: "Cartago, Costa Rica",
        foto: "imagenes/trabajador1.png"
    },
    "520212223": {
        nombre: "Valeria",
        apellidos: "Mejia Durán",
        lugar: "Guanacaste, Costa Rica",
        foto: "imagenes/trabajador2.png"
    },
    "630313233": {
        nombre: "Roberto",
        apellidos: "Salazar Menezes",
        lugar: "Puntarenas, Costa Rica",
        foto: "imagenes/trabajador3.png"
    },
    "140414243": {
        nombre: "Elena",
        apellidos: "Mora Ballestero",
        lugar: "San Jose, Costa Rica",
        foto: "imagenes/trabajador4.png"
    },
    "480818283": {
        nombre: "Pablo",
        apellidos: "Hernandez Rojas",
        lugar: "Heredia, Costa Rica",
        foto: "imagenes/trabajador5.png"
    }
};

function buscarEmple() {
    const cedula = document.getElementById('cedula').value;
    const info_emple = document.getElementById('info_emple');
    const error = document.getElementById('error');

    if (empleados[cedula]) {
        
        document.getElementById('nombre').innerText = empleados[cedula].nombre;
        document.getElementById('apellidos').innerText = empleados[cedula].apellidos;
        document.getElementById('lugar').innerText = empleados[cedula].lugar;
        document.getElementById('foto').src = empleados[cedula].foto;

        info_emple.style.display = 'block';
        error.style.display = 'none';
    } else {
        Swal.fire({
            title: "error",
            text: "Este usuario no existe",
            icon: "error"
          });
    }
}