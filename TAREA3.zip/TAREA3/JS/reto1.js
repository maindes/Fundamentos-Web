function facturar() {
    const cliente = document.getElementById('cliente').value;
    const articulo = document.getElementById('articulo').value;
    const cantidad = parseInt(document.getElementById('cantidad').value);
    const precio = parseFloat(document.getElementById('precio').value);
    
    if (cliente && articulo && cantidad > 0 && precio > 0) {

        const subtotal = cantidad * precio;
        const iva = subtotal * 0.13;
        const servicio = subtotal * 0.05;
        const total = subtotal + iva + servicio;

        document.getElementById('facturaNumero').textContent = Math.floor(Math.random() * 100) + 1;
        document.getElementById('fecha').textContent = new Date().toLocaleString();
        document.getElementById('facturaCliente').textContent = cliente;
        document.getElementById('facturaArticulo').textContent = articulo;
        document.getElementById('facturaCantidad').textContent = cantidad;
        document.getElementById('facturaPrecio').textContent = `₡${precio.toFixed(2)}`;
        document.getElementById('facturaSubtotal').textContent = `₡${subtotal.toFixed(2)}`;
        document.getElementById('facturaIVA').textContent = `₡${iva.toFixed(2)}`;
        document.getElementById('facturaServicio').textContent = `₡${servicio.toFixed(2)}`;
        document.getElementById('facturaTotal').textContent = `₡${total.toFixed(2)}`;
        
        document.getElementById('facturaResultado').style.display = 'block';
    } else {
        Swal.fire({
            icon: "error",
            title: "Ocurrio un error",
            showConfirmButton: 'Ok',
            text: "Debe llenar todos los espacios" 
          });
    }
}

function borrar() {
    document.getElementById("cliente").value = "";
    document.getElementById("articulo").value = "";
    document.getElementById("cantidad").value = "";
    document.getElementById("precio").value = "";
}

