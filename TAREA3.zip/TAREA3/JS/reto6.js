function carro1() {
    document.getElementById("carros").src = "imagenes/carro1.png"
    document.getElementById("diseño").innerHTML = "Moka Metalico (GGF)";
}

function carro2() {
    document.getElementById("carros").src = "imagenes/carro2.png"
    document.getElementById("diseño").innerHTML = "Tiburon Metalicco (GRS2)"
}

function carro3() {
    document.getElementById("carros").src = "imagenes/carro3.png"
    document.getElementById("diseño").innerHTML = "Azul Lunar Metalico (GSK)"
}

function carro4() {
    document.getElementById("carros").src = "imagenes/carro4.png"
    document.getElementById("diseño").innerHTML = "Negro Grafito Metalico (GB8)"
}

function carro5() {
    document.getElementById("carros").src = "imagenes/carroInicio.png"
    document.getElementById("diseño").innerHTML = "Blanco(GAZ)"
}

