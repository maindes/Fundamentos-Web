let estudiantes = [];

        document.getElementById("form-estudiante").addEventListener("submit", function(event) {
            event.preventDefault();

            const nombre = document.getElementById("nombre").value;
            const apellido = document.getElementById("apellido").value;
            const nota1 = parseFloat(document.getElementById("nota1").value);
            const nota2 = parseFloat(document.getElementById("nota2").value);
            const nota3 = parseFloat(document.getElementById("nota3").value);

            if (!nombre || !apellido) {
                Swal.fire({
                    title: "Error",
                    text: "Debe completar todos los campos de nombre y apellido.",
                    icon: "warning"
                });
                return;
            }

            
            if (isNaN(nota1) || isNaN(nota2) || isNaN(nota3)) {
                Swal.fire({
                    title: "Error",
                    text: "Debe ingresar las tres notas.",
                    icon: "warning",
                  });
                return;
            }

            if (nota1 < 0 || nota1 > 100 || nota2 < 0 || nota2 > 100 || nota3 < 0 || nota3 > 100) {
                Swal.fire({
                    title: "Error",
                    text: "Las notas debene estar entre 0 y 100",
                    icon: "error"
                });
                return;
            }

            const estudiante = {
                nombre,
                apellido,
                notas: [nota1, nota2, nota3]
            };

            estudiantes.push(estudiante);
            actEstudiantes();
            limpiarFormulario();

            Swal.fire({
                icon: 'success',
                title: 'Estudiante Añadido',
                text: `El estudiante ${nombre} ${apellido} ha sido registrado con éxito.`,
            });
        });

        function limpiarFormulario() {
            document.getElementById("form-estudiante").reset();
        }

        function actEstudiantes() {
            const combo = document.getElementById("estudiantes");
            combo.innerHTML = `<option value="" selected disabled>Seleccione un estudiante</option>`;
            estudiantes.forEach((est, index) => {
                const option = document.createElement("option");
                option.value = index;
                option.textContent = `${est.nombre} ${est.apellido}`;
                combo.appendChild(option);
            });
        }

        document.getElementById("calcularPromedio").addEventListener("click", function() {
            const est = document.getElementById("estudiantes").value;
            if (est === "") {
                Swal.fire({
                    icon: 'warning',
                    title: 'Seleccione un estudiante',
                    text: 'Debe seleccionar un estudiante para calcular su promedio',
                });
                return;
            }
        
            const estudiante = estudiantes[est];
            const promedio = (estudiante.notas.reduce((a, b) => a + b, 0)) / estudiante.notas.length;
        
            Swal.fire({
                icon: 'success',
                title: 'Promedio Calculado',
                text: `El promedio de ${estudiante.nombre} ${estudiante.apellido} es: ${promedio.toFixed(2)}`, 
            });
        });