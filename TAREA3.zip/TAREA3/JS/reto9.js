document.getElementById("mostrarResultado").addEventListener("click", function() {
    
    const lenguajeCurso = document.querySelector('input[name="curso"]:checked');
    let curso = lenguajeCurso ? lenguajeCurso.value : '';

    const nivelCurso = document.querySelectorAll('input[name="opcion"]:checked');
    let opciones = Array.from(nivelCurso).map(opcion => opcion.value).join(', ');

        if (!curso) {
        Swal.fire({
            icon: 'warning',
            title: 'error',
            text: 'Debe seleccionar un curso.',
            showConfirmButton: false,
            timer: 2500,
        });
        return;
    }

    if (opciones.length === 0) {
        Swal.fire({
            icon: 'warning',
            title: 'error',
            text: 'Debe seleccionar una opción.',
            showConfirmButton: false,
            timer: 2500,
        });
        return;
    }

    Swal.fire({
        icon: 'success',
        title: '¡Felicidades!',
        text: `Su curso es: ${curso}. Su interes fue: ${opciones}.`,
        showConfirmButton: false,
        timer: 5000,
    });
});

function limpiar() {
    document.getElementById('curso1').checked = false;
    document.getElementById('curso2').checked = false;
    document.getElementById('curso3').checked = false;

    document.getElementById('opcion1').checked = false;
    document.getElementById('opcion2').checked = false;
    document.getElementById('opcion3').checked = false;
}