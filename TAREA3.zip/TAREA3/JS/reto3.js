function redireccion() {
    const selectElement = document.getElementById("rest");
    const selectedValue = selectElement.value;

    if (selectedValue) {
        window.location.href = selectedValue;
    }
}